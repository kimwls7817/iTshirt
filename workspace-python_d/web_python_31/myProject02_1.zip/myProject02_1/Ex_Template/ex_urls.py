from django.urls import path
from . import views

app_name = 'Ex_Template' # app_name ����.

urlpatterns = [
    path('', views.index, name='index'),

]