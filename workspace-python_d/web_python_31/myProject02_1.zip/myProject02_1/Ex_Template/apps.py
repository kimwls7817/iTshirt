from django.apps import AppConfig


class ExTemplateConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Ex_Template'
